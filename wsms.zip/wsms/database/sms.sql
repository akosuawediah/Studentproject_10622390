-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2018 at 05:54 AM
-- Server version: 5.6.17
-- PHP Version: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `sms`
--

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE IF NOT EXISTS `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(30) NOT NULL,
  `lname` varchar(30) NOT NULL,
  `idnumber` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `dateofbirth` date NOT NULL,
  `gender` enum('female','male') NOT NULL,
  `nextofkin` varchar(30) NOT NULL,
  `relationship` varchar(30) NOT NULL,
  `postaladdress` varchar(50) NOT NULL,
  `programme` varchar(50) NOT NULL,
  `phone` varchar(13) NOT NULL,
  `guardianfname` varchar(30) NOT NULL,
  `guardianlastname` varchar(30) NOT NULL,
  `grelationship` varchar(30) NOT NULL,
  `guardianphone` varchar(13) NOT NULL,
  `guardianadd` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`id`, `firstname`, `lname`, `idnumber`, `email`, `dateofbirth`, `gender`, `nextofkin`, `relationship`, `postaladdress`, `programme`, `phone`, `guardianfname`, `guardianlastname`, `grelationship`, `guardianphone`, `guardianadd`) VALUES
(1, 'Mercy', 'Wediah', '00225545', 'wediah@gmail.com', '2018-10-02', 'female', 'Gordon', 'Brother', 'Accra', 'Computer Science', '0546484338', 'Gordon', 'Fiifi', 'Brother', '0546484339', 'hdsadsad');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'whedy', 'november'),
(2, 'jame', 'asdfgh'),
(3, 'maxwel', 'hack'),
(4, 'akwasi', 'hammer'),
(5, 'mansa', 'mansa'),
(6, 'shamful', 'denver');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
